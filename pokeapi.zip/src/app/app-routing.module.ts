import { PokeapiComponent } from './pokeapi/pokeapi.component';
import { InformcaoComponent } from './informcao/informcao.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { SobreComponent } from './sobre/sobre.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'sobre',
    component: SobreComponent,
  },
  {
    path: 'info',
    component: InformcaoComponent,
  },
  {
    path: 'pokeapi',
    component: PokeapiComponent,
  },
  {
    path: '**',
    component: NotfoundComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
