import { RequestService } from './../service/request.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pokeapi',
  templateUrl: './pokeapi.component.html',
  styleUrls: ['./pokeapi.component.css'],
})
export class PokeapiComponent implements OnInit {
  dados: any;
  constructor(private service: RequestService) { }

  ngOnInit(): void {
    this.get();
  }

  get(): void {
    this.service.getPokeAPI().subscribe(
      (data) => {
        this.dados = data;
        console.log(data);
      },
      (error) => {
        console.error (error);
      }
      );
  }
}
