import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sobre',
  templateUrl: './sobre.component.html',
  styleUrls: ['./sobre.component.css']
})
export class SobreComponent implements OnInit {
  texto: string = 'Titulo';
  numero: number = 5;
  arr= ['Paulo', 'Roberto', 'Morais'];
  arr1 = [1, 2, 3, 4, 5, 6];
  constructor() { }

  ngOnInit(): void {}

}
