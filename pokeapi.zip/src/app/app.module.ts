import { PokeapiComponent } from './pokeapi/pokeapi.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SobreComponent } from './sobre/sobre.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { InformcaoComponent } from './informcao/informcao.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    SobreComponent,
    NotfoundComponent,
    InformcaoComponent,
    PokeapiComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
