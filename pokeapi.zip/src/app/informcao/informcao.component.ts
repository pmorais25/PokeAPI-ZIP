import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-informcao',
  templateUrl: './informcao.component.html',
  styleUrls: ['./informcao.component.css']
})
export class InformcaoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
