import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InformcaoComponent } from './informcao.component';

describe('InformcaoComponent', () => {
  let component: InformcaoComponent;
  let fixture: ComponentFixture<InformcaoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InformcaoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InformcaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
